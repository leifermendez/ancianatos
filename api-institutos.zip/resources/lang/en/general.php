<?php

return [


    'error' => 'Algo ocurrio, vuelve a intentarlo',
    'unauthenticated' => 'Debes iniciar session',
    'not.found' => 'No se encontro',
    'not.permission' => 'No tienes permisos',

];
